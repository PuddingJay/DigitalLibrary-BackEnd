const express = require("express");
const router = express.Router();
const db = require("../Config/database/db");
const controller = require("../controller/indexController");



module.exports = router;
